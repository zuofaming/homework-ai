# 快速开始指南

## 1. 环境准备

### 系统要求
- Node.js 16+
- npm 或 yarn
- FFmpeg（用于视频处理）

### 安装 FFmpeg

**macOS**:
```bash
brew install ffmpeg
```

**Ubuntu/Debian**:
```bash
sudo apt-get update
sudo apt-get install ffmpeg
```

**Windows**:
下载并安装：https://ffmpeg.org/download.html

验证安装：
```bash
ffmpeg -version
```

## 2. 获取 API Key

### 通义千问 API Key
1. 访问 [阿里云通义千问](https://dashscope.aliyun.com/)
2. 注册/登录账号
3. 创建 API Key
4. 保存你的 API Key

### 图片生成 API Key
可选方案：
- **通义万相**: https://dashscope.aliyun.com/
- **DALL-E**: https://platform.openai.com/
- 其他支持的图片生成 API

## 3. 安装项目

### 下载项目
```bash
# 解压下载的压缩包
unzip heritage-video-ai.zip
cd heritage-video-ai
```

### 安装依赖

**方式一：一键安装（推荐）**
```bash
npm run install-all
```

**方式二：分别安装**
```bash
# 安装后端依赖
cd server
npm install

# 安装前端依赖
cd ../client
npm install
```

## 4. 配置环境变量

在 `server` 目录创建 `.env` 文件：

```bash
cd server
cp .env.example .env
```

编辑 `.env` 文件，填入你的配置：

```bash
PORT=5000
QWEN_API_KEY=your_qwen_api_key_here
IMAGE_GEN_API_KEY=your_image_gen_api_key_here
NODE_ENV=development

VIDEO_OUTPUT_DIR=./output/videos
IMAGE_OUTPUT_DIR=./output/images
TEMP_DIR=./temp

# 如果 FFmpeg 不在系统 PATH 中，指定路径
# FFMPEG_PATH=/usr/local/bin/ffmpeg
```

## 5. 启动项目

### 方式一：同时启动前后端（推荐）

```bash
# 在项目根目录
npm run dev
```

### 方式二：分别启动

**终端 1 - 启动后端**:
```bash
cd server
npm start
```

**终端 2 - 启动前端**:
```bash
cd client
npm start
```

启动成功后：
- 后端服务：http://localhost:5000
- 前端应用：http://localhost:3000

## 6. 使用应用

### 步骤 1: 配置 API Key

1. 打开浏览器访问 http://localhost:3000
2. 在顶部输入你的通义千问 API Key
3. 输入图片生成 API Key
4. API Key 会自动保存到浏览器本地存储

### 步骤 2: 生成脚本

1. 输入非遗文化主题，例如：
   - "景德镇青花瓷制作工艺"
   - "苏州刺绣传承"
   - "京剧艺术表演"
2. 设置视频时长（60-600 秒）
3. 设置场景数量（3-10 个）
4. 选择视频风格（纪录片/科普/故事化/宣传片）
5. 点击"生成脚本"按钮
6. 等待 AI 生成完整的视频脚本（约 10-30 秒）

### 步骤 3: 生成图片

1. 查看生成的脚本，可以手动编辑调整
2. 点击"开始生成图片"按钮
3. AI 将为每个场景生成对应的图片
4. 这个过程可能需要较长时间（取决于场景数量）
5. 生成过程中会显示进度

### 步骤 4: 合成视频

1. 预览所有生成的图片
2. 点击"开始合成视频"按钮
3. 系统会将图片、音频合成为完整视频
4. 显示合成进度条
5. 合成完成后自动跳转到预览页面

### 步骤 5: 预览和下载

1. 在线预览生成的视频
2. 查看视频信息（时长、分辨率等）
3. 点击"下载视频"按钮保存到本地
4. 分享到社交媒体或其他平台

## 7. 示例主题

以下是一些推荐的非遗文化主题：

**传统手工艺**:
- 景德镇陶瓷制作工艺
- 苏州刺绣技艺传承
- 宜兴紫砂壶制作
- 景泰蓝制作工艺
- 中国剪纸艺术

**传统表演艺术**:
- 京剧艺术表演
- 昆曲的传承与发展
- 中国皮影戏
- 木偶戏表演艺术

**传统节日习俗**:
- 中国春节传统习俗
- 端午节龙舟竞渡
- 中秋节月饼制作
- 元宵节花灯艺术

**民间音乐**:
- 古琴艺术
- 古筝演奏技艺
- 二胡表演艺术

## 8. 常见问题

### Q: 脚本生成失败？
**A**:
- 检查通义千问 API Key 是否正确
- 检查网络连接
- 查看浏览器控制台错误信息

### Q: 图片生成失败？
**A**:
- 检查图片生成 API Key 是否正确
- API 可能有调用频率限制，稍后重试
- 某些场景可能需要手动调整提示词

### Q: 视频合成失败？
**A**:
- 确认 FFmpeg 已正确安装
- 检查服务器磁盘空间是否充足
- 查看服务器日志获取详细错误信息

### Q: 视频生成很慢？
**A**:
- 视频生成需要时间，取决于场景数量和服务器性能
- 建议减少场景数量或降低分辨率
- 使用更高性能的服务器

### Q: 如何提高生成质量？
**A**:
- 提供更详细的主题描述
- 手动编辑和优化生成的脚本
- 调整图片生成提示词
- 选择合适的视频风格

## 9. 性能优化建议

1. **服务器配置**:
   - CPU: 4 核以上
   - 内存: 8GB 以上
   - 磁盘: 100GB SSD

2. **并发控制**:
   - 限制同时生成的视频数量
   - 使用队列管理生成任务

3. **缓存策略**:
   - 缓存已生成的脚本和图片
   - 定期清理过期文件

## 10. 下一步

- 查看 [API 文档](./API.md) 了解详细接口
- 查看 [部署指南](./DEPLOYMENT.md) 部署到生产环境
- 查看 [开发指南](./DEVELOPMENT.md) 进行二次开发

---

遇到问题？请查看项目 README 或提交 Issue。
