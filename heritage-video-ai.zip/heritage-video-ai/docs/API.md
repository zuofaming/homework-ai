# API 文档

## 基础信息

- **Base URL**: `http://localhost:5000/api`
- **Content-Type**: `application/json`

## 接口列表

### 1. 生成视频脚本

**接口**: `POST /generate/script`

**描述**: 根据非遗文化主题生成完整的视频脚本

**请求体**:
```json
{
  "topic": "景德镇青花瓷制作工艺",
  "duration": 300,
  "scenes": 5,
  "style": "纪录片",
  "apiKey": "your_qwen_api_key"
}
```

**参数说明**:
- `topic` (必填): 非遗文化主题
- `duration` (可选): 视频时长（秒），默认 300
- `scenes` (可选): 场景数量，默认 5
- `style` (可选): 视频风格，默认 "纪录片"
- `apiKey` (必填): 通义千问 API Key

**响应**:
```json
{
  "success": true,
  "data": {
    "title": "千年窑火：景德镇青花瓷的艺术传承",
    "scenes": [
      {
        "id": 1,
        "title": "开场：千年瓷都",
        "duration": 60,
        "narration": "解说词...",
        "visualDescription": "视觉描述...",
        "imagePrompt": "English prompt for AI"
      }
    ],
    "totalDuration": 300,
    "backgroundMusic": "traditional-chinese-instrumental"
  }
}
```

---

### 2. 生成场景图片

**接口**: `POST /generate/images`

**描述**: 为所有场景批量生成图片

**请求体**:
```json
{
  "scenes": [
    {
      "id": 1,
      "title": "场景标题",
      "imagePrompt": "Detailed English prompt..."
    }
  ],
  "resolution": "1920x1080",
  "style": "realistic",
  "apiKey": "your_image_api_key"
}
```

**参数说明**:
- `scenes` (必填): 场景列表数组
- `resolution` (可选): 分辨率，默认 "1920x1080"
- `style` (可选): 图片风格，默认 "realistic"
- `apiKey` (必填): 图片生成 API Key

**响应**:
```json
{
  "success": true,
  "data": {
    "total": 5,
    "success": 4,
    "failed": 1,
    "images": [
      {
        "sceneId": 1,
        "filename": "scene_1_uuid.jpg",
        "url": "/output/images/scene_1_uuid.jpg",
        "prompt": "Original prompt"
      }
    ]
  }
}
```

---

### 3. 生成单张图片

**接口**: `POST /generate/image`

**描述**: 生成单张图片

**请求体**:
```json
{
  "prompt": "Chinese traditional porcelain...",
  "resolution": "1920x1080",
  "style": "realistic",
  "apiKey": "your_image_api_key"
}
```

**响应**:
```json
{
  "success": true,
  "data": {
    "filename": "single_uuid.jpg",
    "url": "/output/images/single_uuid.jpg"
  }
}
```

---

### 4. 合成视频

**接口**: `POST /generate/video`

**描述**: 将图片合成为完整视频

**请求体**:
```json
{
  "scenes": [
    {
      "id": 1,
      "duration": 60,
      "imageFile": "scene_1_uuid.jpg"
    }
  ],
  "resolution": "1920x1080",
  "fps": 30,
  "transition": "fade",
  "backgroundMusic": null
}
```

**参数说明**:
- `scenes` (必填): 场景列表，必须包含 imageFile
- `resolution` (可选): 视频分辨率
- `fps` (可选): 帧率，默认 30
- `transition` (可选): 转场效果，默认 "fade"
- `backgroundMusic` (可选): 背景音乐文件路径

**响应**:
```json
{
  "success": true,
  "data": {
    "taskId": "task_uuid",
    "message": "视频生成任务已启动"
  }
}
```

---

### 5. 查询生成进度

**接口**: `GET /generate/progress/:taskId`

**描述**: 查询视频生成进度

**响应**:
```json
{
  "success": true,
  "data": {
    "status": "completed",
    "progress": 100,
    "message": "视频生成完成",
    "filename": "heritage_video_uuid.mp4",
    "url": "/output/videos/heritage_video_uuid.mp4",
    "downloadUrl": "/api/export/video/heritage_video_uuid.mp4"
  }
}
```

**状态说明**:
- `processing`: 处理中
- `completed`: 已完成
- `failed`: 失败

---

### 6. 下载视频

**接口**: `GET /export/video/:filename`

**描述**: 下载生成的视频文件

---

### 7. 下载图片

**接口**: `GET /export/image/:filename`

**描述**: 下载生成的图片文件

---

### 8. 获取视频列表

**接口**: `GET /export/videos`

**描述**: 获取所有已生成的视频列表

**响应**:
```json
{
  "success": true,
  "data": [
    {
      "filename": "heritage_video_uuid.mp4",
      "size": 15728640,
      "createdAt": "2024-01-01T12:00:00.000Z",
      "url": "/output/videos/heritage_video_uuid.mp4"
    }
  ]
}
```

---

### 9. 健康检查

**接口**: `GET /health`

**描述**: 检查服务器状态

**响应**:
```json
{
  "success": true,
  "message": "非遗文化视频 AI 生成器 - 服务运行中",
  "timestamp": "2024-01-01T12:00:00.000Z"
}
```

---

## 错误响应

所有接口的错误响应格式统一为：

```json
{
  "success": false,
  "error": "错误信息描述"
}
```

常见错误码：
- `400`: 请求参数错误
- `404`: 资源不存在
- `500`: 服务器内部错误

---

## 使用示例

### JavaScript (Axios)

```javascript
import axios from 'axios';

// 生成脚本
const generateScript = async () => {
  const response = await axios.post('http://localhost:5000/api/generate/script', {
    topic: '景德镇青花瓷制作工艺',
    duration: 300,
    scenes: 5,
    style: '纪录片',
    apiKey: 'your_api_key'
  });

  console.log(response.data);
};
```

### cURL

```bash
# 生成脚本
curl -X POST http://localhost:5000/api/generate/script \
  -H "Content-Type: application/json" \
  -d '{
    "topic": "景德镇青花瓷制作工艺",
    "duration": 300,
    "scenes": 5,
    "style": "纪录片",
    "apiKey": "your_api_key"
  }'
```

---

## 注意事项

1. **API Key 安全**: 不要在客户端代码中硬编码 API Key
2. **请求限流**: 图片生成 API 可能有频率限制
3. **文件清理**: 服务器会定期清理临时文件
4. **超时设置**: 视频生成可能需要较长时间，建议设置合适的超时时间
5. **并发控制**: 建议限制同时生成的视频数量

---

## 更新日志

### v1.0.0 (2024-01-01)
- 初始版本发布
- 支持脚本生成、图片生成、视频合成
