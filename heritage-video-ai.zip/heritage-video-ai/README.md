# 非遗文化视频 AI 生成器 🎬

基于 AI 的非物质文化遗产视频自动生成系统，支持文本到视频脚本、AI 绘画、配音合成等功能。

## ✨ 核心功能

### 1. 📝 智能脚本生成
- 输入非遗文化主题（如：景德镇陶瓷、苏绣、京剧等）
- AI 自动生成完整的视频脚本
- 包含场景描述、解说词、镜头建议

### 2. 🎨 AI 图片生成
- 根据脚本自动生成每个场景的图片
- 支持多种艺术风格（国画、水墨、写实等）
- 高质量分辨率输出

### 3. 🎬 视频素材整合
- 自动将图片转换为视频片段
- 添加转场效果和特效
- 支持自定义时长和分辨率

### 4. 🔊 智能配音
- AI 语音合成解说词
- 支持多种音色和语速
- 自动添加背景音乐（传统音乐）

### 5. 📦 一键导出
- 生成完整的 MP4 视频文件
- 支持多种分辨率（720p、1080p、4K）
- 包含字幕文件（SRT）

## 🏗️ 技术架构

```
heritage-video-ai/
├── client/                 # React 前端
│   ├── public/            # 静态资源
│   └── src/
│       ├── components/    # UI 组件
│       │   ├── VideoGenerator.js    # 视频生成器主组件
│       │   ├── ScriptEditor.js      # 脚本编辑器
│       │   ├── ImageGallery.js      # 图片预览
│       │   └── VideoPreview.js      # 视频预览
│       ├── services/      # API 服务
│       │   ├── api.js
│       │   └── videoService.js
│       ├── App.js
│       └── index.js
├── server/                # Node.js 后端
│   ├── routes/           # API 路由
│   │   ├── generate.js   # 生成路由
│   │   └── export.js     # 导出路由
│   ├── controllers/      # 控制器
│   │   ├── scriptController.js
│   │   ├── imageController.js
│   │   └── videoController.js
│   ├── services/         # 业务逻辑
│   │   ├── qwenService.js        # 通义千问服务
│   │   ├── imageGenService.js   # 图片生成服务
│   │   └── videoService.js      # 视频合成服务
│   └── server.js
├── docs/                 # 文档
└── examples/            # 示例
```

### 技术栈

**前端：**
- React 18
- Axios（HTTP 客户端）
- Ant Design（UI 组件库）
- Video.js（视频播放器）

**后端：**
- Node.js
- Express
- FFmpeg（视频处理）
- CORS

**AI 服务：**
- 阿里云通义千问（文本生成）
- 通义万相（图片生成）
- 或其他开放 AI 模型接口

## 🚀 快速开始

### 前置要求

- Node.js 16+
- FFmpeg（用于视频处理）
- 通义千问 API Key
- 图片生成 API Key（如 DALL-E、Midjourney API、通义万相等）

### 安装 FFmpeg

**macOS:**
```bash
brew install ffmpeg
```

**Ubuntu/Debian:**
```bash
sudo apt-get install ffmpeg
```

**Windows:**
下载并安装：https://ffmpeg.org/download.html

### 安装步骤

1. **克隆项目**
```bash
git clone <your-repo-url>
cd heritage-video-ai
```

2. **安装依赖**
```bash
# 安装后端依赖
cd server
npm install

# 安装前端依赖
cd ../client
npm install
```

3. **配置环境变量**

在 `server` 目录创建 `.env` 文件：

```bash
PORT=5000
QWEN_API_KEY=your_qwen_api_key_here
IMAGE_GEN_API_KEY=your_image_gen_api_key_here
NODE_ENV=development

# 视频配置
VIDEO_OUTPUT_DIR=./output/videos
IMAGE_OUTPUT_DIR=./output/images
TEMP_DIR=./temp

# FFmpeg 路径（如果不在系统 PATH 中）
# FFMPEG_PATH=/usr/local/bin/ffmpeg
```

4. **启动项目**

终端1 - 启动后端：
```bash
cd server
npm start
```

终端2 - 启动前端：
```bash
cd client
npm start
```

- 后端服务：`http://localhost:5000`
- 前端应用：`http://localhost:3000`

## 📖 使用说明

### 1. 输入非遗主题
- 在主页输入你想要制作视频的非遗文化主题
- 例如："景德镇青花瓷制作工艺"、"苏州刺绣传承"等
- 可以添加更多细节要求

### 2. 生成视频脚本
- 点击"生成脚本"按钮
- AI 将生成完整的视频脚本，包括：
  - 开场白
  - 多个场景描述
  - 解说词
  - 结束语

### 3. 编辑和调整
- 可以手动编辑生成的脚本
- 调整场景顺序
- 修改解说词内容

### 4. 生成图片
- 点击"生成图片"按钮
- AI 根据每个场景描述生成对应图片
- 预览所有生成的图片

### 5. 合成视频
- 设置视频参数（分辨率、时长、转场效果等）
- 点击"生成视频"按钮
- 等待视频合成完成

### 6. 下载和分享
- 预览生成的视频
- 下载 MP4 文件
- 可选下载字幕文件

## 🎯 非遗文化主题示例

系统支持所有非物质文化遗产主题，例如：

**传统手工艺：**
- 景德镇陶瓷制作
- 苏州刺绣
- 宜兴紫砂壶
- 景泰蓝制作
- 剪纸艺术

**传统表演艺术：**
- 京剧艺术
- 昆曲表演
- 皮影戏
- 木偶戏

**传统节日习俗：**
- 春节习俗
- 端午节龙舟
- 中秋月饼制作
- 元宵花灯

**民间音乐：**
- 古琴艺术
- 古筝演奏
- 二胡技艺

## 🔧 API 文档

### 1. 生成视频脚本

```http
POST /api/generate/script
Content-Type: application/json

{
  "topic": "景德镇青花瓷制作工艺",
  "duration": 300,  // 视频时长（秒）
  "scenes": 5,      // 场景数量
  "style": "纪录片"  // 风格：纪录片、科普、故事化
}
```

响应：
```json
{
  "success": true,
  "data": {
    "title": "千年窑火：景德镇青花瓷的艺术传承",
    "scenes": [
      {
        "id": 1,
        "title": "开场：千年瓷都",
        "duration": 60,
        "narration": "在江西景德镇，千年窑火生生不息...",
        "visualDescription": "航拍景德镇全景，古窑遗址，袅袅炊烟",
        "imagePrompt": "Aerial view of Jingdezhen ancient kilns, traditional Chinese architecture, misty morning, cinematic style"
      }
      // ... 更多场景
    ],
    "totalDuration": 300,
    "backgroundMusic": "traditional-chinese-instrumental"
  }
}
```

### 2. 生成场景图片

```http
POST /api/generate/images
Content-Type: application/json

{
  "scenes": [
    {
      "id": 1,
      "imagePrompt": "Aerial view of Jingdezhen...",
      "style": "realistic"
    }
  ],
  "resolution": "1920x1080"
}
```

### 3. 合成视频

```http
POST /api/generate/video
Content-Type: application/json

{
  "scriptId": "script_123",
  "images": ["img1.jpg", "img2.jpg"],
  "narrations": ["audio1.mp3", "audio2.mp3"],
  "resolution": "1920x1080",
  "fps": 30,
  "transitions": "fade"
}
```

## 🎨 视频样式配置

### 图片风格选项
- `realistic` - 写实风格
- `chinese-painting` - 国画风格
- `watercolor` - 水彩风格
- `documentary` - 纪录片风格

### 转场效果
- `fade` - 淡入淡出
- `dissolve` - 溶解
- `wipe` - 擦除
- `slide` - 滑动

### 分辨率选项
- `1280x720` - 720p HD
- `1920x1080` - 1080p Full HD
- `3840x2160` - 4K Ultra HD

## 📦 项目脚本

```bash
# server 目录
npm start              # 启动后端服务
npm run dev           # 开发模式（自动重启）

# client 目录
npm start             # 启动前端开发服务器
npm run build         # 构建生产版本

# 根目录
npm run install-all   # 安装所有依赖
npm run dev          # 同时启动前后端
```

## 🔐 安全说明

- API Key 加密存储
- 生成的视频文件定期清理
- 支持用户认证和授权
- 限制并发生成数量

## 📝 注意事项

1. 视频生成可能需要较长时间（取决于场景数量和分辨率）
2. 确保有足够的磁盘空间存储临时文件
3. 建议使用高性能服务器进行视频合成
4. 图片生成 API 可能有调用频率限制

## 🚀 部署建议

### 推荐配置
- CPU: 4 核以上
- 内存: 8GB 以上
- 磁盘: 100GB SSD
- 带宽: 100Mbps

### Docker 部署
```bash
docker-compose up -d
```

## 🤝 贡献指南

欢迎提交 Issue 和 Pull Request！

## 📄 开源协议

MIT License

## 🙏 致谢

- 阿里云通义千问 - AI 文本生成
- FFmpeg - 视频处理
- React - 前端框架
- Express - 后端框架

---

⭐ 如果这个项目对你有帮助，欢迎 Star！
