import React from 'react';
import { Card, Button, Image, Row, Col, Tag, Empty } from 'antd';
import { PlayCircleOutlined, CheckCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';
import videoService from '../services/videoService';
import './ImageGallery.css';

function ImageGallery({ images, scriptData, onNext }) {
  if (!images || images.length === 0) {
    return (
      <Card className="image-gallery-card" title={<><span>🖼️</span> 生成的图片</>}>
        <Empty description="暂无图片" />
      </Card>
    );
  }

  return (
    <Card className="image-gallery-card" title={<><span>🖼️</span> 生成的图片</>}>
      <div className="gallery-header">
        <p className="gallery-stats">
          成功生成 <span className="success-count">{images.filter(img => !img.error).length}</span> 张图片
          {images.filter(img => img.error).length > 0 && (
            <span className="error-count">
              , {images.filter(img => img.error).length} 张失败
            </span>
          )}
        </p>
      </div>

      <Row gutter={[16, 16]} className="image-grid">
        {images.map((imageData, index) => {
          const scene = scriptData.scenes.find(s => s.id === imageData.sceneId);

          return (
            <Col xs={24} sm={12} md={8} lg={6} key={index}>
              <div className="image-item">
                {imageData.error ? (
                  <div className="image-error">
                    <CloseCircleOutlined style={{ fontSize: 48, color: '#ff4d4f' }} />
                    <p>生成失败</p>
                    <p className="error-message">{imageData.error}</p>
                  </div>
                ) : (
                  <>
                    <div className="image-wrapper">
                      <Image
                        src={videoService.getImageUrl(imageData.filename)}
                        alt={`场景 ${imageData.sceneId}`}
                        className="scene-image"
                        preview={{
                          mask: <div className="image-mask">查看大图</div>
                        }}
                      />
                      <div className="image-overlay">
                        <Tag color="purple" icon={<CheckCircleOutlined />}>
                          场景 {imageData.sceneId}
                        </Tag>
                      </div>
                    </div>
                    {scene && (
                      <div className="image-info">
                        <h4 className="scene-name">{scene.title}</h4>
                        <p className="scene-desc">{scene.visualDescription.substring(0, 60)}...</p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </Col>
          );
        })}
      </Row>

      <div className="action-buttons">
        <Button
          type="primary"
          size="large"
          icon={<PlayCircleOutlined />}
          onClick={onNext}
          disabled={images.filter(img => !img.error).length === 0}
        >
          开始合成视频
        </Button>
      </div>
    </Card>
  );
}

export default ImageGallery;
