import React, { useState } from 'react';
import { Card, Form, Input, Button, Select, InputNumber, message, Spin } from 'antd';
import { PlayCircleOutlined, PictureOutlined, FileTextOutlined, DownloadOutlined } from '@ant-design/icons';
import ScriptEditor from './ScriptEditor';
import ImageGallery from './ImageGallery';
import VideoPreview from './VideoPreview';
import videoService from '../services/videoService';
import './VideoGenerator.css';

const { TextArea } = Input;
const { Option } = Select;

function VideoGenerator({
  currentStep,
  setCurrentStep,
  scriptData,
  setScriptData,
  generatedImages,
  setGeneratedImages,
  videoUrl,
  setVideoUrl
}) {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [apiKey, setApiKey] = useState(localStorage.getItem('qwen_api_key') || '');
  const [imageApiKey, setImageApiKey] = useState(localStorage.getItem('image_api_key') || '');

  // 步骤 1: 生成脚本
  const handleGenerateScript = async (values) => {
    if (!apiKey) {
      message.error('请先输入通义千问 API Key');
      return;
    }

    setLoading(true);
    try {
      const response = await videoService.generateScript(
        values.topic,
        values.duration || 300,
        values.scenes || 5,
        values.style || '纪录片',
        apiKey
      );

      if (response.success) {
        setScriptData(response.data);
        setCurrentStep(1);
        message.success('脚本生成成功！');
      }
    } catch (error) {
      message.error(`生成失败: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // 步骤 2: 生成图片
  const handleGenerateImages = async () => {
    if (!imageApiKey) {
      message.error('请先输入图片生成 API Key');
      return;
    }

    if (!scriptData || !scriptData.scenes) {
      message.error('请先生成脚本');
      return;
    }

    setLoading(true);
    try {
      const response = await videoService.generateImages(
        scriptData.scenes,
        '1920x1080',
        'realistic',
        imageApiKey
      );

      if (response.success) {
        setGeneratedImages(response.data.images);
        setCurrentStep(2);
        message.success(`成功生成 ${response.data.success} 张图片！`);
      }
    } catch (error) {
      message.error(`生成失败: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // 步骤 3: 合成视频
  const handleGenerateVideo = async () => {
    if (!generatedImages || generatedImages.length === 0) {
      message.error('请先生成图片');
      return;
    }

    setLoading(true);
    try {
      // 准备场景数据
      const scenes = scriptData.scenes.map((scene, index) => {
        const imageData = generatedImages.find(img => img.sceneId === scene.id);
        return {
          id: scene.id,
          duration: scene.duration,
          imageFile: imageData?.filename
        };
      });

      const response = await videoService.generateVideo(
        scenes,
        '1920x1080',
        30,
        'fade'
      );

      if (response.success) {
        const taskId = response.data.taskId;
        message.success('视频生成任务已启动，正在处理...');

        // 轮询检查进度
        const checkProgress = setInterval(async () => {
          try {
            const progressResponse = await videoService.getProgress(taskId);
            if (progressResponse.success) {
              const progress = progressResponse.data;

              if (progress.status === 'completed') {
                clearInterval(checkProgress);
                setVideoUrl(progress.url);
                setCurrentStep(3);
                setLoading(false);
                message.success('视频生成完成！');
              } else if (progress.status === 'failed') {
                clearInterval(checkProgress);
                setLoading(false);
                message.error(`视频生成失败: ${progress.message}`);
              }
            }
          } catch (error) {
            console.error('获取进度失败:', error);
          }
        }, 2000);
      }
    } catch (error) {
      message.error(`生成失败: ${error.message}`);
      setLoading(false);
    }
  };

  // 保存 API Key
  const handleApiKeyChange = (e) => {
    const key = e.target.value;
    setApiKey(key);
    localStorage.setItem('qwen_api_key', key);
  };

  const handleImageApiKeyChange = (e) => {
    const key = e.target.value;
    setImageApiKey(key);
    localStorage.setItem('image_api_key', key);
  };

  return (
    <div className="video-generator">
      <Spin spinning={loading} size="large" tip="处理中，请稍候...">
        {/* API Key 配置 */}
        <Card className="api-config-card" title="API 配置">
          <Form layout="vertical">
            <Form.Item label="通义千问 API Key" tooltip="用于生成脚本">
              <Input.Password
                value={apiKey}
                onChange={handleApiKeyChange}
                placeholder="请输入通义千问 API Key"
              />
            </Form.Item>
            <Form.Item label="图片生成 API Key" tooltip="用于生成场景图片">
              <Input.Password
                value={imageApiKey}
                onChange={handleImageApiKeyChange}
                placeholder="请输入图片生成 API Key"
              />
            </Form.Item>
          </Form>
        </Card>

        {/* 步骤 0: 输入主题 */}
        {currentStep === 0 && (
          <Card className="main-card" title={<><FileTextOutlined /> 生成视频脚本</>}>
            <Form form={form} layout="vertical" onFinish={handleGenerateScript}>
              <Form.Item
                label="非遗文化主题"
                name="topic"
                rules={[{ required: true, message: '请输入主题' }]}
              >
                <TextArea
                  rows={4}
                  placeholder="例如：景德镇青花瓷制作工艺、苏州刺绣传承、京剧艺术..."
                />
              </Form.Item>

              <div className="form-row">
                <Form.Item label="视频时长（秒）" name="duration" initialValue={300}>
                  <InputNumber min={60} max={600} style={{ width: '100%' }} />
                </Form.Item>

                <Form.Item label="场景数量" name="scenes" initialValue={5}>
                  <InputNumber min={3} max={10} style={{ width: '100%' }} />
                </Form.Item>

                <Form.Item label="视频风格" name="style" initialValue="纪录片">
                  <Select>
                    <Option value="纪录片">纪录片</Option>
                    <Option value="科普">科普</Option>
                    <Option value="故事化">故事化</Option>
                    <Option value="宣传片">宣传片</Option>
                  </Select>
                </Form.Item>
              </div>

              <Form.Item>
                <Button type="primary" htmlType="submit" size="large" block icon={<FileTextOutlined />}>
                  生成脚本
                </Button>
              </Form.Item>
            </Form>
          </Card>
        )}

        {/* 步骤 1: 编辑脚本 */}
        {currentStep === 1 && scriptData && (
          <ScriptEditor
            scriptData={scriptData}
            setScriptData={setScriptData}
            onNext={handleGenerateImages}
          />
        )}

        {/* 步骤 2: 查看图片 */}
        {currentStep === 2 && generatedImages.length > 0 && (
          <ImageGallery
            images={generatedImages}
            scriptData={scriptData}
            onNext={handleGenerateVideo}
          />
        )}

        {/* 步骤 3: 预览视频 */}
        {currentStep === 3 && videoUrl && (
          <VideoPreview
            videoUrl={videoUrl}
            scriptData={scriptData}
          />
        )}
      </Spin>
    </div>
  );
}

export default VideoGenerator;
