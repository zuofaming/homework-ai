import React from 'react';
import { Card, Button, Descriptions, Tag } from 'antd';
import { DownloadOutlined, CheckCircleOutlined } from '@ant-design/icons';
import videoService from '../services/videoService';
import './VideoPreview.css';

function VideoPreview({ videoUrl, scriptData }) {
  const handleDownload = () => {
    // 从 URL 提取文件名
    const filename = videoUrl.split('/').pop();
    const downloadUrl = videoService.getVideoDownloadUrl(filename);

    // 创建隐藏的下载链接
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Card className="video-preview-card" title={<><CheckCircleOutlined /> 视频生成完成</>}>
      <div className="success-message">
        <CheckCircleOutlined className="success-icon" />
        <h2 className="success-title">恭喜！视频已成功生成</h2>
        <p className="success-desc">您的非遗文化视频已经准备好了，可以预览和下载。</p>
      </div>

      {scriptData && (
        <Descriptions
          title="视频信息"
          bordered
          column={2}
          className="video-info"
        >
          <Descriptions.Item label="视频标题" span={2}>
            {scriptData.title}
          </Descriptions.Item>
          <Descriptions.Item label="场景数量">
            {scriptData.scenes?.length || 0} 个
          </Descriptions.Item>
          <Descriptions.Item label="总时长">
            {scriptData.totalDuration} 秒
          </Descriptions.Item>
          <Descriptions.Item label="分辨率">
            <Tag color="blue">1920x1080 (Full HD)</Tag>
          </Descriptions.Item>
          <Descriptions.Item label="帧率">
            <Tag color="green">30 FPS</Tag>
          </Descriptions.Item>
        </Descriptions>
      )}

      <div className="video-container">
        <video
          controls
          className="video-player"
          src={videoUrl}
          poster=""
        >
          您的浏览器不支持视频播放。
        </video>
      </div>

      <div className="action-buttons">
        <Button
          type="primary"
          size="large"
          icon={<DownloadOutlined />}
          onClick={handleDownload}
        >
          下载视频
        </Button>
      </div>

      <div className="tips-section">
        <h3>💡 使用建议</h3>
        <ul>
          <li>视频已自动保存在服务器，可随时下载</li>
          <li>建议使用 1080p 或更高分辨率观看以获得最佳体验</li>
          <li>可以在社交媒体分享，传播非遗文化</li>
          <li>如需重新生成，请刷新页面重新开始</li>
        </ul>
      </div>
    </Card>
  );
}

export default VideoPreview;
