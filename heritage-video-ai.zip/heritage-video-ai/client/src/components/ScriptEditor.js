import React from 'react';
import { Card, Button, Descriptions, Timeline, Tag } from 'antd';
import { PictureOutlined, ClockCircleOutlined } from '@ant-design/icons';
import './ScriptEditor.css';

function ScriptEditor({ scriptData, setScriptData, onNext }) {
  if (!scriptData) return null;

  const { title, scenes, totalDuration } = scriptData;

  return (
    <Card className="script-editor-card" title={<><span>📝</span> 视频脚本</>}>
      <div className="script-header">
        <h2 className="script-title">{title}</h2>
        <Tag color="purple" icon={<ClockCircleOutlined />}>
          总时长: {totalDuration} 秒
        </Tag>
      </div>

      <Timeline className="scene-timeline">
        {scenes && scenes.map((scene, index) => (
          <Timeline.Item
            key={scene.id}
            color="purple"
            dot={<span className="scene-number">{index + 1}</span>}
          >
            <div className="scene-card">
              <div className="scene-header">
                <h3 className="scene-title">{scene.title}</h3>
                <Tag color="blue">{scene.duration} 秒</Tag>
              </div>

              <Descriptions column={1} size="small">
                <Descriptions.Item label="解说词">
                  <div className="narration-text">{scene.narration}</div>
                </Descriptions.Item>
                <Descriptions.Item label="视觉描述">
                  <div className="visual-text">{scene.visualDescription}</div>
                </Descriptions.Item>
                <Descriptions.Item label="图片提示词">
                  <div className="prompt-text">{scene.imagePrompt}</div>
                </Descriptions.Item>
              </Descriptions>
            </div>
          </Timeline.Item>
        ))}
      </Timeline>

      <div className="action-buttons">
        <Button type="primary" size="large" icon={<PictureOutlined />} onClick={onNext}>
          开始生成图片
        </Button>
      </div>
    </Card>
  );
}

export default ScriptEditor;
