import React, { useState } from 'react';
import { Layout, Card, Steps, message } from 'antd';
import VideoGenerator from './components/VideoGenerator';
import './App.css';

const { Header, Content, Footer } = Layout;
const { Step } = Steps;

function App() {
  const [currentStep, setCurrentStep] = useState(0);
  const [scriptData, setScriptData] = useState(null);
  const [generatedImages, setGeneratedImages] = useState([]);
  const [videoUrl, setVideoUrl] = useState(null);

  const steps = [
    { title: '生成脚本', description: '输入主题，AI 生成视频脚本' },
    { title: '生成图片', description: '为每个场景生成精美图片' },
    { title: '合成视频', description: '将图片合成为完整视频' },
    { title: '完成导出', description: '预览和下载视频' }
  ];

  return (
    <Layout className="app-layout">
      <Header className="app-header">
        <div className="header-content">
          <h1 className="app-title">
            <span className="title-icon">🎬</span>
            非遗文化视频 AI 生成器
          </h1>
          <p className="app-subtitle">用 AI 讲述中国传统文化故事</p>
        </div>
      </Header>

      <Content className="app-content">
        <div className="content-wrapper">
          <Card className="steps-card">
            <Steps current={currentStep} className="custom-steps">
              {steps.map((step, index) => (
                <Step key={index} title={step.title} description={step.description} />
              ))}
            </Steps>
          </Card>

          <VideoGenerator
            currentStep={currentStep}
            setCurrentStep={setCurrentStep}
            scriptData={scriptData}
            setScriptData={setScriptData}
            generatedImages={generatedImages}
            setGeneratedImages={setGeneratedImages}
            videoUrl={videoUrl}
            setVideoUrl={setVideoUrl}
          />
        </div>
      </Content>

      <Footer className="app-footer">
        <p>非遗文化视频 AI 生成器 © 2024 - 传承中华文化，用科技连接传统</p>
      </Footer>
    </Layout>
  );
}

export default App;
