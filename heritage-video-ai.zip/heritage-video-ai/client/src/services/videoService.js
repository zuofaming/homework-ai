import api from './api';

/**
 * 视频服务 API
 */
const videoService = {
  /**
   * 生成视频脚本
   */
  generateScript: async (topic, duration, scenes, style, apiKey) => {
    return await api.post('/api/generate/script', {
      topic,
      duration,
      scenes,
      style,
      apiKey
    });
  },

  /**
   * 生成场景图片
   */
  generateImages: async (scenes, resolution, style, apiKey) => {
    return await api.post('/api/generate/images', {
      scenes,
      resolution,
      style,
      apiKey
    });
  },

  /**
   * 生成单张图片
   */
  generateSingleImage: async (prompt, resolution, style, apiKey) => {
    return await api.post('/api/generate/image', {
      prompt,
      resolution,
      style,
      apiKey
    });
  },

  /**
   * 合成视频
   */
  generateVideo: async (scenes, resolution, fps, transition, backgroundMusic) => {
    return await api.post('/api/generate/video', {
      scenes,
      resolution,
      fps,
      transition,
      backgroundMusic
    });
  },

  /**
   * 获取生成进度
   */
  getProgress: async (taskId) => {
    return await api.get(`/api/generate/progress/${taskId}`);
  },

  /**
   * 获取视频列表
   */
  getVideoList: async () => {
    return await api.get('/api/export/videos');
  },

  /**
   * 获取视频下载URL
   */
  getVideoDownloadUrl: (filename) => {
    return `${api.defaults.baseURL}/api/export/video/${filename}`;
  },

  /**
   * 获取图片URL
   */
  getImageUrl: (filename) => {
    return `${api.defaults.baseURL}/output/images/${filename}`;
  }
};

export default videoService;
