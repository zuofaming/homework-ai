const ffmpeg = require('fluent-ffmpeg');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

/**
 * 视频合成服务
 * 使用 FFmpeg 将图片和音频合成为视频
 */
class VideoService {
  constructor() {
    // 设置 FFmpeg 路径（如果需要）
    if (process.env.FFMPEG_PATH) {
      ffmpeg.setFfmpegPath(process.env.FFMPEG_PATH);
    }

    this.outputDir = process.env.VIDEO_OUTPUT_DIR || './output/videos';
    this.tempDir = process.env.TEMP_DIR || './temp';
  }

  /**
   * 创建视频
   * @param {Array} scenes - 场景列表
   * @param {string} resolution - 分辨率
   * @param {number} fps - 帧率
   * @param {string} transition - 转场效果
   * @param {string} backgroundMusic - 背景音乐文件
   * @param {Function} progressCallback - 进度回调
   */
  async createVideo(scenes, resolution, fps, transition, backgroundMusic, progressCallback) {
    const outputFilename = `heritage_video_${uuidv4()}.mp4`;
    const outputPath = path.join(this.outputDir, outputFilename);

    try {
      console.log('开始合成视频...');

      // 1. 创建每个场景的视频片段
      const videoSegments = [];
      for (let i = 0; i < scenes.length; i++) {
        const scene = scenes[i];
        const segmentPath = await this.createSceneVideo(scene, resolution, fps);
        videoSegments.push(segmentPath);

        if (progressCallback) {
          progressCallback((i + 1) / scenes.length * 50); // 0-50%
        }
      }

      // 2. 合并所有片段
      await this.mergeVideos(videoSegments, outputPath, transition, backgroundMusic, (progress) => {
        if (progressCallback) {
          progressCallback(50 + progress * 0.5); // 50-100%
        }
      });

      // 3. 清理临时文件
      videoSegments.forEach(segment => {
        if (fs.existsSync(segment)) {
          fs.unlinkSync(segment);
        }
      });

      console.log('✓ 视频合成完成:', outputFilename);
      return outputFilename;

    } catch (error) {
      console.error('视频合成失败:', error);
      throw error;
    }
  }

  /**
   * 为单个场景创建视频片段
   */
  async createSceneVideo(scene, resolution, fps) {
    return new Promise((resolve, reject) => {
      const imageDir = process.env.IMAGE_OUTPUT_DIR || './output/images';
      const imagePath = path.join(imageDir, scene.imageFile);

      if (!fs.existsSync(imagePath)) {
        return reject(new Error(`图片文件不存在: ${scene.imageFile}`));
      }

      const duration = scene.duration || 5; // 默认5秒
      const outputPath = path.join(this.tempDir, `segment_${scene.id}_${uuidv4()}.mp4`);

      const [width, height] = resolution.split('x').map(Number);

      ffmpeg(imagePath)
        .loop(duration)
        .fps(fps)
        .size(`${width}x${height}`)
        .videoCodec('libx264')
        .outputOptions([
          '-pix_fmt yuv420p',
          '-t ' + duration
        ])
        .output(outputPath)
        .on('end', () => {
          console.log(`✓ 场景 ${scene.id} 视频片段已创建`);
          resolve(outputPath);
        })
        .on('error', (err) => {
          console.error(`× 场景 ${scene.id} 视频片段创建失败:`, err);
          reject(err);
        })
        .run();
    });
  }

  /**
   * 合并多个视频片段
   */
  async mergeVideos(videoSegments, outputPath, transition, backgroundMusic, progressCallback) {
    return new Promise((resolve, reject) => {
      // 创建拼接列表文件
      const concatListPath = path.join(this.tempDir, `concat_${uuidv4()}.txt`);
      const concatList = videoSegments.map(v => `file '${path.resolve(v)}'`).join('\n');
      fs.writeFileSync(concatListPath, concatList);

      const command = ffmpeg()
        .input(concatListPath)
        .inputOptions(['-f concat', '-safe 0'])
        .videoCodec('libx264')
        .audioCodec('aac')
        .outputOptions([
          '-pix_fmt yuv420p',
          '-preset medium',
          '-crf 23'
        ]);

      // 如果有背景音乐
      if (backgroundMusic && fs.existsSync(backgroundMusic)) {
        command.input(backgroundMusic)
          .complexFilter([
            '[0:v]null[v]',
            '[1:a]volume=0.3[a]'
          ])
          .map('[v]')
          .map('[a]');
      }

      command
        .output(outputPath)
        .on('progress', (progress) => {
          if (progressCallback && progress.percent) {
            progressCallback(progress.percent);
          }
        })
        .on('end', () => {
          // 清理临时文件
          if (fs.existsSync(concatListPath)) {
            fs.unlinkSync(concatListPath);
          }
          console.log('✓ 视频合并完成');
          resolve(outputPath);
        })
        .on('error', (err) => {
          console.error('× 视频合并失败:', err);
          reject(err);
        })
        .run();
    });
  }

  /**
   * 添加字幕到视频
   */
  async addSubtitles(videoPath, subtitlePath, outputPath) {
    return new Promise((resolve, reject) => {
      ffmpeg(videoPath)
        .outputOptions([
          `-vf subtitles=${subtitlePath}`
        ])
        .output(outputPath)
        .on('end', () => {
          console.log('✓ 字幕已添加');
          resolve(outputPath);
        })
        .on('error', reject)
        .run();
    });
  }
}

module.exports = new VideoService();
