const axios = require('axios');

/**
 * 图片生成服务
 * 支持多种图片生成 API
 */
class ImageGenService {
  constructor() {
    this.apiUrl = process.env.IMAGE_GEN_API_URL || 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis';
  }

  /**
   * 生成图片
   * @param {string} prompt - 图片描述
   * @param {string} resolution - 分辨率 (例如: "1920x1080")
   * @param {string} apiKey - API Key
   */
  async generateImage(prompt, resolution = '1920x1080', apiKey) {
    try {
      console.log('生成图片:', prompt.substring(0, 100) + '...');

      // 解析分辨率
      const [width, height] = resolution.split('x').map(Number);

      // 使用通义万相 API
      const response = await axios.post(
        this.apiUrl,
        {
          model: 'wanx-v1',
          input: {
            prompt: prompt
          },
          parameters: {
            size: `${width}*${height}`,
            n: 1
          }
        },
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            'X-DashScope-Async': 'enable'
          },
          timeout: 120000
        }
      );

      if (response.data && response.data.output) {
        const taskId = response.data.output.task_id;

        // 轮询获取结果
        const imageUrl = await this.pollTaskResult(taskId, apiKey);
        return imageUrl;
      }

      throw new Error('图片生成 API 返回格式错误');

    } catch (error) {
      console.error('图片生成失败:', error.message);

      // 如果通义万相失败，返回占位图片
      if (error.response) {
        console.error('Response data:', error.response.data);
      }

      // 返回占位图片URL（或使用本地默认图片）
      return await this.generatePlaceholder(prompt, resolution);
    }
  }

  /**
   * 轮询任务结果
   */
  async pollTaskResult(taskId, apiKey, maxAttempts = 30) {
    const pollUrl = `https://dashscope.aliyuncs.com/api/v1/tasks/${taskId}`;

    for (let i = 0; i < maxAttempts; i++) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // 等待2秒

      try {
        const response = await axios.get(pollUrl, {
          headers: {
            'Authorization': `Bearer ${apiKey}`
          }
        });

        if (response.data && response.data.output) {
          const status = response.data.output.task_status;

          if (status === 'SUCCEEDED') {
            const imageUrl = response.data.output.results[0].url;
            console.log('✓ 图片生成成功');
            return imageUrl;
          } else if (status === 'FAILED') {
            throw new Error('图片生成任务失败');
          }

          console.log(`等待图片生成... (${i + 1}/${maxAttempts})`);
        }
      } catch (error) {
        console.error('轮询失败:', error.message);
      }
    }

    throw new Error('图片生成超时');
  }

  /**
   * 生成占位图片（使用 placeholder 服务或本地生成）
   */
  async generatePlaceholder(prompt, resolution) {
    const [width, height] = resolution.split('x').map(Number);

    // 使用公共占位图片服务
    const placeholderUrl = `https://via.placeholder.com/${width}x${height}/6366f1/ffffff?text=${encodeURIComponent('Heritage Culture Image')}`;

    console.log('使用占位图片');
    return placeholderUrl;
  }

  /**
   * 使用其他图片生成 API（如 DALL-E）
   */
  async generateWithDALLE(prompt, resolution, apiKey) {
    // 这里可以集成 OpenAI DALL-E API
    // 作为备用方案
    throw new Error('DALL-E integration not implemented');
  }
}

module.exports = new ImageGenService();
