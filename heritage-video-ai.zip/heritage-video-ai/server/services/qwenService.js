const axios = require('axios');

/**
 * 通义千问服务 - 文本生成
 */
class QwenService {
  constructor() {
    this.apiUrl = process.env.QWEN_API_URL || 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation';
  }

  /**
   * 生成文本
   * @param {string} prompt - 提示词
   * @param {string} apiKey - API Key
   * @param {string} model - 模型名称
   */
  async generateText(prompt, apiKey, model = 'qwen-max') {
    try {
      console.log('调用通义千问 API...');

      const response = await axios.post(
        this.apiUrl,
        {
          model: model,
          input: {
            messages: [
              {
                role: 'system',
                content: '你是一个专业的非物质文化遗产视频脚本创作专家，擅长用生动的语言和画面描述来展现传统文化的魅力。'
              },
              {
                role: 'user',
                content: prompt
              }
            ]
          },
          parameters: {
            result_format: 'message',
            max_tokens: 2000,
            temperature: 0.7,
            top_p: 0.8
          }
        },
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 60000
        }
      );

      if (response.data && response.data.output && response.data.output.choices) {
        const content = response.data.output.choices[0].message.content;

        // 尝试解析 JSON
        try {
          // 提取 JSON 部分（可能包含在代码块中）
          let jsonStr = content;
          const jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/) || content.match(/```\s*([\s\S]*?)\s*```/);
          if (jsonMatch) {
            jsonStr = jsonMatch[1];
          }

          const result = JSON.parse(jsonStr);
          console.log('✓ 脚本生成成功');
          return result;
        } catch (parseError) {
          console.error('JSON 解析失败，返回原始内容');
          // 如果解析失败，返回格式化的默认结构
          return {
            title: '非遗文化视频',
            content: content,
            scenes: []
          };
        }
      }

      throw new Error('API 返回格式错误');

    } catch (error) {
      console.error('通义千问 API 调用失败:', error.message);
      if (error.response) {
        console.error('Response data:', error.response.data);
        throw new Error(error.response.data.message || '调用 AI 服务失败');
      }
      throw error;
    }
  }

  /**
   * 优化图片生成提示词
   */
  async enhanceImagePrompt(description, apiKey) {
    const prompt = `请将以下中文描述转换为适合 AI 图片生成的详细英文提示词：

"${description}"

要求：
1. 使用专业的摄影和艺术术语
2. 包含风格、光线、构图等细节
3. 适合 DALL-E、Midjourney 等工具
4. 只返回英文提示词，不要其他内容

示例格式：
"Traditional Chinese porcelain workshop, master craftsman painting delicate blue patterns, warm lighting, cinematic composition, 4k quality, detailed textures, documentary style"`;

    try {
      const response = await this.generateText(prompt, apiKey, 'qwen-max');
      return response.content || response;
    } catch (error) {
      console.error('提示词优化失败:', error.message);
      // 返回简单的翻译版本
      return `Chinese traditional culture, ${description}, high quality, detailed, cinematic`;
    }
  }
}

module.exports = new QwenService();
