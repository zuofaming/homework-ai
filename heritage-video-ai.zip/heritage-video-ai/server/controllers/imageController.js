const imageGenService = require('../services/imageGenService');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

/**
 * 生成多张场景图片
 */
exports.generateImages = async (req, res) => {
  try {
    const { scenes, resolution = '1920x1080', style = 'realistic', apiKey } = req.body;

    if (!scenes || !Array.isArray(scenes) || scenes.length === 0) {
      return res.status(400).json({
        success: false,
        error: '请提供场景列表'
      });
    }

    const key = apiKey || process.env.IMAGE_GEN_API_KEY;
    if (!key) {
      return res.status(400).json({
        success: false,
        error: '请提供图片生成 API Key'
      });
    }

    console.log(`生成 ${scenes.length} 张图片...`);

    const results = [];
    const imageDir = process.env.IMAGE_OUTPUT_DIR || './output/images';

    // 依次生成每个场景的图片
    for (let i = 0; i < scenes.length; i++) {
      const scene = scenes[i];
      console.log(`正在生成场景 ${i + 1}/${scenes.length}: ${scene.title || scene.id}`);

      try {
        // 增强提示词
        const enhancedPrompt = `${scene.imagePrompt}, ${style} style, high quality, 4k, detailed, professional photography`;

        // 调用图片生成服务
        const imageData = await imageGenService.generateImage(enhancedPrompt, resolution, key);

        // 保存图片
        const filename = `scene_${scene.id}_${uuidv4()}.jpg`;
        const filepath = path.join(imageDir, filename);

        // 如果返回的是 base64
        if (imageData.startsWith('data:image')) {
          const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
          fs.writeFileSync(filepath, Buffer.from(base64Data, 'base64'));
        } else {
          // 如果返回的是 URL，需要下载
          const axios = require('axios');
          const response = await axios.get(imageData, { responseType: 'arraybuffer' });
          fs.writeFileSync(filepath, response.data);
        }

        results.push({
          sceneId: scene.id,
          filename: filename,
          url: `/output/images/${filename}`,
          prompt: scene.imagePrompt
        });

        console.log(`✓ 场景 ${i + 1} 图片已生成: ${filename}`);

      } catch (error) {
        console.error(`× 场景 ${i + 1} 生成失败:`, error.message);
        results.push({
          sceneId: scene.id,
          error: error.message
        });
      }

      // 添加延迟，避免 API 限流
      if (i < scenes.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    res.json({
      success: true,
      data: {
        total: scenes.length,
        success: results.filter(r => !r.error).length,
        failed: results.filter(r => r.error).length,
        images: results
      }
    });

  } catch (error) {
    console.error('生成图片失败:', error);
    res.status(500).json({
      success: false,
      error: error.message || '生成图片失败'
    });
  }
};

/**
 * 生成单张图片
 */
exports.generateSingleImage = async (req, res) => {
  try {
    const { prompt, resolution = '1920x1080', style = 'realistic', apiKey } = req.body;

    if (!prompt) {
      return res.status(400).json({
        success: false,
        error: '请提供图片描述'
      });
    }

    const key = apiKey || process.env.IMAGE_GEN_API_KEY;
    const enhancedPrompt = `${prompt}, ${style} style, high quality, 4k`;

    const imageData = await imageGenService.generateImage(enhancedPrompt, resolution, key);

    // 保存图片
    const filename = `single_${uuidv4()}.jpg`;
    const imageDir = process.env.IMAGE_OUTPUT_DIR || './output/images';
    const filepath = path.join(imageDir, filename);

    if (imageData.startsWith('data:image')) {
      const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
      fs.writeFileSync(filepath, Buffer.from(base64Data, 'base64'));
    } else {
      const axios = require('axios');
      const response = await axios.get(imageData, { responseType: 'arraybuffer' });
      fs.writeFileSync(filepath, response.data);
    }

    res.json({
      success: true,
      data: {
        filename: filename,
        url: `/output/images/${filename}`
      }
    });

  } catch (error) {
    console.error('生成图片失败:', error);
    res.status(500).json({
      success: false,
      error: error.message || '生成图片失败'
    });
  }
};
