const qwenService = require('../services/qwenService');

/**
 * 生成视频脚本
 */
exports.generateScript = async (req, res) => {
  try {
    const { topic, duration = 300, scenes = 5, style = '纪录片', apiKey } = req.body;

    // 验证输入
    if (!topic) {
      return res.status(400).json({
        success: false,
        error: '请提供非遗文化主题'
      });
    }

    // 使用传入的 API Key 或环境变量中的
    const key = apiKey || process.env.QWEN_API_KEY;
    if (!key) {
      return res.status(400).json({
        success: false,
        error: '请提供通义千问 API Key'
      });
    }

    console.log(`生成脚本 - 主题: ${topic}, 时长: ${duration}s, 场景数: ${scenes}, 风格: ${style}`);

    // 构建提示词
    const prompt = `请为非物质文化遗产主题"${topic}"创作一个${style}风格的视频脚本。

要求：
1. 视频总时长约 ${duration} 秒
2. 分为 ${scenes} 个场景
3. 每个场景包含：场景标题、时长、解说词、视觉描述、英文图片生成提示词
4. 解说词要生动、专业、富有文化内涵
5. 视觉描述要具体、适合 AI 绘画
6. 英文提示词要详细，适合 DALL-E 或 Midjourney 等 AI 绘画工具

请严格按照以下 JSON 格式返回（不要包含任何其他文本）：

{
  "title": "视频标题",
  "scenes": [
    {
      "id": 1,
      "title": "场景标题",
      "duration": 60,
      "narration": "解说词内容...",
      "visualDescription": "视觉描述（中文）",
      "imagePrompt": "Detailed English prompt for AI image generation, cinematic style, high quality"
    }
  ],
  "totalDuration": ${duration},
  "backgroundMusic": "traditional-chinese-instrumental"
}`;

    // 调用通义千问 API
    const scriptData = await qwenService.generateText(prompt, key);

    res.json({
      success: true,
      data: scriptData
    });

  } catch (error) {
    console.error('生成脚本失败:', error);
    res.status(500).json({
      success: false,
      error: error.message || '生成脚本失败'
    });
  }
};
