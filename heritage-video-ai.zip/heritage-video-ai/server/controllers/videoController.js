const videoService = require('../services/videoService');
const { v4: uuidv4 } = require('uuid');

// 存储任务进度
const taskProgress = new Map();

/**
 * 生成视频
 */
exports.generateVideo = async (req, res) => {
  try {
    const {
      scenes,
      resolution = '1920x1080',
      fps = 30,
      transition = 'fade',
      backgroundMusic
    } = req.body;

    if (!scenes || !Array.isArray(scenes) || scenes.length === 0) {
      return res.status(400).json({
        success: false,
        error: '请提供场景列表'
      });
    }

    // 验证每个场景都有图片
    const missingImages = scenes.filter(s => !s.imageFile);
    if (missingImages.length > 0) {
      return res.status(400).json({
        success: false,
        error: `场景 ${missingImages.map(s => s.id).join(', ')} 缺少图片文件`
      });
    }

    // 创建任务 ID
    const taskId = uuidv4();
    taskProgress.set(taskId, {
      status: 'processing',
      progress: 0,
      message: '开始生成视频...'
    });

    console.log(`开始生成视频 - 任务ID: ${taskId}`);

    // 异步生成视频
    generateVideoAsync(taskId, scenes, resolution, fps, transition, backgroundMusic);

    // 立即返回任务ID
    res.json({
      success: true,
      data: {
        taskId: taskId,
        message: '视频生成任务已启动，请使用任务ID查询进度'
      }
    });

  } catch (error) {
    console.error('生成视频失败:', error);
    res.status(500).json({
      success: false,
      error: error.message || '生成视频失败'
    });
  }
};

/**
 * 获取生成进度
 */
exports.getProgress = (req, res) => {
  const { taskId } = req.params;

  if (!taskProgress.has(taskId)) {
    return res.status(404).json({
      success: false,
      error: '任务不存在'
    });
  }

  const progress = taskProgress.get(taskId);
  res.json({
    success: true,
    data: progress
  });

  // 如果任务已完成或失败，30秒后清除
  if (progress.status === 'completed' || progress.status === 'failed') {
    setTimeout(() => {
      taskProgress.delete(taskId);
    }, 30000);
  }
};

/**
 * 异步生成视频
 */
async function generateVideoAsync(taskId, scenes, resolution, fps, transition, backgroundMusic) {
  try {
    // 更新进度：准备素材
    taskProgress.set(taskId, {
      status: 'processing',
      progress: 10,
      message: '准备视频素材...'
    });

    // 生成视频
    const outputFilename = await videoService.createVideo(
      scenes,
      resolution,
      fps,
      transition,
      backgroundMusic,
      (progress) => {
        // 更新进度回调
        taskProgress.set(taskId, {
          status: 'processing',
          progress: 10 + progress * 0.9, // 10% - 100%
          message: `正在合成视频... ${Math.round(progress)}%`
        });
      }
    );

    // 完成
    taskProgress.set(taskId, {
      status: 'completed',
      progress: 100,
      message: '视频生成完成',
      filename: outputFilename,
      url: `/output/videos/${outputFilename}`,
      downloadUrl: `/api/export/video/${outputFilename}`
    });

    console.log(`✓ 视频生成成功: ${outputFilename}`);

  } catch (error) {
    console.error('视频生成失败:', error);
    taskProgress.set(taskId, {
      status: 'failed',
      progress: 0,
      message: error.message || '视频生成失败'
    });
  }
}
