const express = require('express');
const router = express.Router();
const scriptController = require('../controllers/scriptController');
const imageController = require('../controllers/imageController');
const videoController = require('../controllers/videoController');

// 生成视频脚本
router.post('/script', scriptController.generateScript);

// 生成场景图片
router.post('/images', imageController.generateImages);

// 生成单张图片
router.post('/image', imageController.generateSingleImage);

// 合成视频
router.post('/video', videoController.generateVideo);

// 获取生成进度
router.get('/progress/:taskId', videoController.getProgress);

module.exports = router;
