const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');

// 下载生成的视频
router.get('/video/:filename', (req, res) => {
  const { filename } = req.params;
  const videoDir = process.env.VIDEO_OUTPUT_DIR || './output/videos';
  const filePath = path.join(videoDir, filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      success: false,
      error: '视频文件不存在'
    });
  }

  res.download(filePath, filename, (err) => {
    if (err) {
      console.error('Download error:', err);
      res.status(500).json({
        success: false,
        error: '下载失败'
      });
    }
  });
});

// 下载图片
router.get('/image/:filename', (req, res) => {
  const { filename } = req.params;
  const imageDir = process.env.IMAGE_OUTPUT_DIR || './output/images';
  const filePath = path.join(imageDir, filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      success: false,
      error: '图片文件不存在'
    });
  }

  res.download(filePath, filename);
});

// 获取所有生成的视频列表
router.get('/videos', (req, res) => {
  const videoDir = process.env.VIDEO_OUTPUT_DIR || './output/videos';

  fs.readdir(videoDir, (err, files) => {
    if (err) {
      return res.status(500).json({
        success: false,
        error: '读取视频列表失败'
      });
    }

    const videos = files
      .filter(file => file.endsWith('.mp4'))
      .map(file => {
        const filePath = path.join(videoDir, file);
        const stats = fs.statSync(filePath);
        return {
          filename: file,
          size: stats.size,
          createdAt: stats.birthtime,
          url: `/output/videos/${file}`
        };
      })
      .sort((a, b) => b.createdAt - a.createdAt);

    res.json({
      success: true,
      data: videos
    });
  });
});

module.exports = router;
