# 非遗文化视频 AI 生成器 - 安装说明

## 📦 压缩包内容

```
heritage-video-ai/
├── README.md           # 项目说明文档
├── INSTALL.md          # 本安装说明（你正在阅读）
├── package.json        # 根目录依赖配置
├── .gitignore         # Git 忽略文件
├── client/            # React 前端应用
├── server/            # Node.js 后端服务
├── docs/              # 详细文档
│   ├── API.md         # API 接口文档
│   └── QUICKSTART.md  # 快速开始指南
└── examples/          # 示例和参考
    └── heritage-topics.md  # 非遗主题示例
```

## ⚡ 快速开始（3 步）

### 1️⃣ 安装依赖

```bash
# 解压文件
unzip heritage-video-ai.zip
cd heritage-video-ai

# 一键安装所有依赖
npm run install-all
```

### 2️⃣ 配置 API Key

```bash
# 进入 server 目录
cd server

# 复制环境变量模板
cp .env.example .env

# 编辑 .env 文件，填入你的 API Key
# 使用任意编辑器打开 .env 文件，例如：
# nano .env
# vim .env
# 或使用图形界面编辑器
```

在 `.env` 文件中填入：
```bash
PORT=5000
QWEN_API_KEY=你的通义千问API密钥
IMAGE_GEN_API_KEY=你的图片生成API密钥
NODE_ENV=development
```

### 3️⃣ 启动应用

```bash
# 返回项目根目录
cd ..

# 同时启动前端和后端
npm run dev
```

启动成功后，打开浏览器访问：http://localhost:3000

## 📋 详细安装步骤

### 前置要求

1. **Node.js**: 版本 16 或以上
   - 检查版本：`node --version`
   - 下载地址：https://nodejs.org/

2. **npm**: 通常随 Node.js 一起安装
   - 检查版本：`npm --version`

3. **FFmpeg**: 用于视频处理
   - **macOS**: `brew install ffmpeg`
   - **Ubuntu**: `sudo apt-get install ffmpeg`
   - **Windows**: 从 https://ffmpeg.org/download.html 下载

   检查安装：`ffmpeg -version`

### 获取 API Key

#### 通义千问 API Key（必需）

1. 访问：https://dashscope.aliyun.com/
2. 注册/登录阿里云账号
3. 进入控制台，创建 API Key
4. 复制保存 API Key

#### 图片生成 API Key（必需）

**选项 A - 通义万相（推荐）**:
- 访问：https://dashscope.aliyun.com/
- 开通通义万相服务
- 使用同一个阿里云账号的 API Key

**选项 B - 其他服务**:
- DALL-E：https://platform.openai.com/
- Stable Diffusion API
- Midjourney API（第三方）

### 安装步骤

#### 方式一：自动安装（推荐）

```bash
# 1. 解压文件
unzip heritage-video-ai.zip
cd heritage-video-ai

# 2. 安装所有依赖
npm run install-all

# 3. 配置环境变量
cd server
cp .env.example .env
# 编辑 .env 文件填入 API Key

# 4. 启动应用
cd ..
npm run dev
```

#### 方式二：手动分步安装

```bash
# 1. 解压文件
unzip heritage-video-ai.zip
cd heritage-video-ai

# 2. 安装后端依赖
cd server
npm install

# 3. 配置后端环境变量
cp .env.example .env
# 编辑 .env 文件

# 4. 安装前端依赖
cd ../client
npm install

# 5. 启动后端（新终端）
cd ../server
npm start

# 6. 启动前端（新终端）
cd ../client
npm start
```

## 🔧 配置说明

### 环境变量（server/.env）

```bash
# 服务器端口
PORT=5000

# 通义千问 API Key（必填）
QWEN_API_KEY=sk-xxxxxxxxxxxxx

# 图片生成 API Key（必填）
IMAGE_GEN_API_KEY=sk-xxxxxxxxxxxxx

# 运行环境
NODE_ENV=development

# 输出目录（可选，使用默认值）
VIDEO_OUTPUT_DIR=./output/videos
IMAGE_OUTPUT_DIR=./output/images
TEMP_DIR=./temp

# FFmpeg 路径（可选，如果已在系统 PATH 中则不需要）
# FFMPEG_PATH=/usr/local/bin/ffmpeg

# API 配置（可选，使用默认值）
QWEN_API_URL=https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation
IMAGE_GEN_API_URL=https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis
```

## 🚀 启动应用

### 开发模式

```bash
# 同时启动前后端（推荐）
npm run dev

# 或者分别启动：

# 终端 1 - 后端
npm run server

# 终端 2 - 前端
npm run client
```

### 生产模式

```bash
# 1. 构建前端
npm run build

# 2. 启动后端
cd server
NODE_ENV=production npm start
```

## 📝 使用说明

### 第一次使用

1. 打开浏览器访问：http://localhost:3000
2. 在顶部输入你的 API Key（会自动保存）
3. 输入非遗文化主题，例如："景德镇青花瓷制作工艺"
4. 设置参数后点击"生成脚本"
5. 依次完成：脚本生成 → 图片生成 → 视频合成
6. 预览和下载生成的视频

### 主题示例

查看 `examples/heritage-topics.md` 文件，里面有 30+ 个精选主题示例。

推荐主题：
- 景德镇青花瓷制作工艺
- 苏州刺绣传承
- 京剧艺术表演
- 中国剪纸艺术
- 古琴艺术

## ⚠️ 常见问题

### Q1: npm install 失败？

**解决方案**:
```bash
# 清除 npm 缓存
npm cache clean --force

# 删除 node_modules 重新安装
rm -rf node_modules package-lock.json
npm install
```

### Q2: FFmpeg 未找到？

**解决方案**:
```bash
# 检查 FFmpeg 是否安装
ffmpeg -version

# 如果未安装，根据操作系统安装
# macOS: brew install ffmpeg
# Ubuntu: sudo apt-get install ffmpeg
```

### Q3: API 调用失败？

**解决方案**:
- 检查 API Key 是否正确
- 检查网络连接
- 查看浏览器控制台错误信息
- 检查 API 余额是否充足

### Q4: 端口被占用？

**解决方案**:
```bash
# 修改 server/.env 中的端口
PORT=5001

# 或者杀死占用端口的进程
# macOS/Linux:
lsof -ti:5000 | xargs kill -9

# Windows:
netstat -ano | findstr :5000
taskkill /PID <进程ID> /F
```

### Q5: 视频生成失败？

**解决方案**:
- 确认 FFmpeg 已正确安装
- 检查磁盘空间是否充足
- 查看 server 终端的错误日志
- 减少场景数量重试

## 📚 进阶文档

- **API 文档**: `docs/API.md`
- **快速开始**: `docs/QUICKSTART.md`
- **主题示例**: `examples/heritage-topics.md`

## 🆘 获取帮助

1. 查看项目 README.md
2. 查看详细文档目录（docs/）
3. 检查服务器日志和浏览器控制台
4. 提交 GitHub Issue

## 📊 系统要求

**最低要求**:
- CPU: 双核
- 内存: 4GB
- 磁盘: 20GB

**推荐配置**:
- CPU: 四核以上
- 内存: 8GB 以上
- 磁盘: 100GB SSD
- 网络: 稳定的互联网连接

## 🎉 开始使用

一切准备就绪！现在可以开始创作精彩的非遗文化视频了。

```bash
# 启动应用
npm run dev

# 打开浏览器
# http://localhost:3000

# 开始创作！🎬
```

---

**祝你使用愉快！传承中华文化，用科技连接传统。** 🇨🇳
